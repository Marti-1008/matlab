fonction_pour_G = @(x) (x-3)^3+3*(x-3)^2;
h = 0.001;
x = 1.1;
dereive_G =  @(x) (fonction_pour_G(x+h)-fonction_pour_G(x))/h;
borne_a = 1;
while sqrt(dereive_G(x)^2)>=10^-4
     x = x -0.1*dereive_G(x);
end
disp(x)

f=(@(x) x(1).^2-x(1).*x(2).^2+2*x(1)-x(2)+1);
x=[0, -1];
alpha=0.5;
delta=10^-4;
G=mygrad(f,x);

function Grad=mygrad(f,x)
n=length(x);
h=0.001;
H=eye(n)*h;
Grad= zeros(1,n);
for k=1:n
    Grad(k)=(f(x+H(k,:))-f(x-H(k,:)))/(2*h);
end
end
while (norm(G)>delta)
    x=x-alpha*G;
    G=mygrad(f,x);
end 
x