fonction_gradient = @(x,y) sin(x)*cos(y);
x0 = [0,0];

function x0 =  fonction_derive(x0)
    fonction_gradient = @(x,y) sin(x)*cos(y);
    h = 10^-3;
    x = (fonction_gradient(x0(1)+h,x0(2))-fonction_gradient(x0(1)-h, x0(2)))/(2*h);
    y = (fonction_gradient(x0(1),h+ x0(2))-fonction_gradient(x0(1),-h+ x0(2)))/(2*h);
    x0 = [x, y];
end
while norm(fonction_derive(x0))>10^-9
    x0 = x0 -0.01*fonction_derive(x0);
end
disp(x0)
