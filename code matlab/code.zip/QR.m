A = [12,  7,  5,  3;
     4, 15,  8,  6;
     9, 11, 13,  2;
     5,  2, 14,  7];

[m, n] = size(A);
Q = zeros(m, n);
R = zeros(n);

for x = 1:n
    vecteur_colonne = A(:,x);
    
    for j = 1:x-1
        R(j,x) = dot(vecteur_colonne, Q(:,j));
        vecteur_colonne = vecteur_colonne - R(j,x) * Q(:,j);
    end
    
    R(x,x) = norm(vecteur_colonne);
    Q(:,x) = vecteur_colonne / R(x,x);
end

Solution = Q * R;
difference = A - Solution;
disp('Erreur (norme de la différence entre A et QR) :');
disp(norm(difference));
