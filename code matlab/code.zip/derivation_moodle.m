%{
On considère la fonction f(x)=arctanx

Utiliser la méthode de dérivation d'ordre deux pour estimer f′(1)
 avec h=0.01

Sachant que f′(x)=11+x2
, quelle est l'erreur commise par le logiciel ?
%}


fonction_arctg = @(x) atan(x); 
h=0.01;
a =1;
derive = (fonction_arctg(a+h)-fonction_arctg(a-h))/(2*h);
derive_arctg =@(x) 1/(1+x.^2);
derive_formule = derive_arctg(a);
disp("la différence entre les 2 est de :")
disp(derive_formule-derive) % correct faut juste mettre en valeur absolue