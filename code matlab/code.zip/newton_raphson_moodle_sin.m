fonction_sin = @(x) sin(x);
fonction_prime_sin = @(x) cos(x);
h = 10^-3;
u0 = 3;
while (abs(fonction_sin(u0))>h)
    u0 = u0-(fonction_sin(u0)/fonction_prime_sin(u0));
end 
disp (abs(pi-u0))