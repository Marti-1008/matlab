function [yp] = fonction(t,y)
    yp =y*0;
    R =5;
    L = 10^-3;
    C = 10^-6;
    yp(1) = y(2);
    yp(2) = -(R/L)*y(2) -(1/(L*C)*y(1));
end

y = [10^-4 0];
a = 0;
b = 0.001;
h = 10^-5;
n = (b-a)/(h);
t = a;
absc = [t];
ord1 =[y(1)]; % q
ord2 =[y(2)];
for (x=1:n)
    F1 = fonction(t, y);
    F2 = fonction(t+h/2, y +(h/2)*F1);
    F3 = fonction(t+h/2, y +(h/2)*F2);
    F4 = fonction(t+h, y +h*F3);
    y = y + (h/6)*(F1+2*F2+2*F3+F4);
    t = t +h;
    absc = [absc, t];
    ord2 = [ord2,y(2)];
    ord1 = [ord1, y(1)]; 
end

% Données du circuit
L = 1e-3;   % Inductance en Henrys
R = 5;      % Résistance en Ohms
C = 1e-6;   % Capacité en Farads
q0 = 10^-4;
% Calculs des constantes
omega0 = 1 / sqrt(L * C);            % Pulsation propre ω0 = 1/sqrt(LC)
Q = (1 / R) * sqrt(L / C);             % Facteur de qualité Q = 1/R * sqrt(L/C)
omega = omega0 * sqrt(1 - (1 / (2*Q))^2);  % ω = ω0 * sqrt(1 - (1/(2Q))^2)

% Formule de la charge q(t)
q = @(t) q0 * exp(-omega0.* t / (2*Q) ) .* (cos(omega .* t) + (1 / (2*Q*sqrt(1 - (1/(2*Q))^2))) * sin(omega .* t));

% Formule du courant i(t)
i =@(t) -q0 * omega0 /sqrt(1 - (1 / (2*Q))^2) * exp(-omega0 / (2*Q) * t) .* sin(omega * t);
absc1 = 0:10^-5:0.001;
ord3 = i(absc1);
ord4 = q(absc1);

hold on 
plot(absc, ord1, 'r')
plot(absc1,ord4, 'y')
plot (absc, ord2, 'b')
plot(absc1 , ord3, 'c')
disp("la valeur ")
disp(mean(abs(ord1-ord4))+mean(abs(ord2-ord3)))