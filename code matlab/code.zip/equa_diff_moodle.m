y_prime = @(x,y) -2*x*y^2;
a = 1;
b = 3;
h =10^-2;
y1=1;
y = y1;
absc =[a];
ord=[y];

for (x=a:h:b)
    F1 = y_prime(x,y);
    F2 =y_prime(x+h/2,y + (h/2)*F1);
    F3 =y_prime(x+h/2,y + (h/2)*F2);
    F4 =y_prime(x+h,y + h*F3);
    y = y +(h/6)*(F1+2*F2+2*F3+F4); 
    absc = [absc, x];
    ord = [ord, y];
end

disp(mean(ord))