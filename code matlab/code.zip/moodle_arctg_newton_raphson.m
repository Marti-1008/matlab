arctg = @(x) atan(x);
a =1;
h = 0.01;
derive = (arctg(a+h)-arctg(a-h))/(2*h);
arctg_derive = @(x) 1/(1+x^2);
disp(["la valeur de la différence entre les 2 est de ",mean(abs(derive-arctg_derive(a)))])
