q_zeros = 10^-4;
l = 10^-3;
C = 10^-6;
R = 5;
w0 = 1/sqrt(l*C);
Q = (1/R)*sqrt(l/C);
w = w0* sqrt(1-(1/(2*Q))^2);

charge=@(t) q0*exp(-1*t*w0/(2*Q)).*(cos(w*t)+(1/(2*Q*sqrt(1-(1/(2*Q)^2))).*sin(w*t)));;


courant =@(t) -(q_zeros*w0)/(sqrt(1-(1/(2*Q))^2))* exp(-(w0.*t/(2*Q))) .* sin(w.*t);


a = 0; 
b = 0.001;
h = 10^-6;
absc = [];
ord=[];

for (x=a:h:b)
    y = (charge(x+h)-charge(x-h))/(2*h);
    absc = [absc, x];
    ord = [ord, y];
end

absc2 =[];
ord2 = [];
for (x=a:h:b)
    y = courant(x);
    absc2 = [absc2, x];
    ord2 = [ord2, y];
end
    
hold on 
plot(absc, ord, 'r')
plot (absc2, ord2, 'g')
mean(abs(ord-ord2))